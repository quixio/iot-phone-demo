from streamingdataframes.exceptions import QuixException


class StateManagementDisabledError(QuixException):
    ...
